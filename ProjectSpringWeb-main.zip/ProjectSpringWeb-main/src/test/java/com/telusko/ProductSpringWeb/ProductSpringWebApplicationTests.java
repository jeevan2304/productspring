package com.telusko.ProductSpringWeb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductSpringWebApplicationTests {

	@Test
	void contextLoads() {
	}

}
