
INSERT INTO product(id,name,type,place,warranty) VALUES (1,'LG AC Remote','Remote','White Table',2021);
INSERT INTO product(id,name,type,place,warranty) VALUES (2,'Type C','Cable','Black Drawer',2024);
INSERT INTO product(id,name,type,place,warranty) VALUES (3,'Mac Studio','Computer','White Table',2025);
INSERT INTO product(id,name,type,place,warranty) VALUES (4,'Focusrite Mixer','Audio System','White Table',2025);
INSERT INTO product(id,name,type,place,warranty) VALUES (5,'Asus Vivobook','Laptop','Brown Drawer',2021);
INSERT INTO product(id,name,type,place,warranty) VALUES (6,'Asus Rog','Laptop','Black Table',2021);
INSERT INTO product(id,name,type,place,warranty) VALUES (7,'Macbook pro','Laptop','Brown Drawer',2022);
INSERT INTO product(id,name,type,place,warranty) VALUES (8,'Wacom Pad','Writing Pad','Black Drawer',2020);
INSERT INTO product(id,name,type,place,warranty) VALUES (9,'Apple Keyboard','Keyboard','White Table',2022);
INSERT INTO product(id,name,type,place,warranty) VALUES (10,'Logitech Keyboard','Keyboard','Black Table',2024);
INSERT INTO product(id,name,type,place,warranty) VALUES (11,'Hdmi cable','Cable','Black Drawer',2024);
INSERT INTO product(id,name,type,place,warranty) VALUES (12,'Java Black Book','Cable','Shelf',2024);
INSERT INTO product(id,name,type,place,warranty) VALUES (13,'Logi Mouse','Mouse','Black Table',2022);
INSERT INTO product(id,name,type,place,warranty) VALUES (14,'Apple Mouse','Mouse','White Table',2022);
INSERT INTO product(id,name,type,place,warranty) VALUES (15,'Lenovo Mouse','Mouse','Black Drawer',2022);
INSERT INTO product(id,name,type,place,warranty) VALUES (16,'BlackBeast','Computer','White Table',2020);
INSERT INTO product(id,name,type,place,warranty) VALUES (17,'Airpods','Earphone','White Table',2022);
